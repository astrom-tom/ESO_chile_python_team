# A Python script to query the GAIA catalogue and propagate the proper motions to a forward
#
# Written April 2019, F.P.A. Vogt; fvogt@eso.org
# ----------------------------------------------------------------------------------------


# Import the packages
import warnings
import astropy.units as u
from astropy.coordinates import SkyCoord
from astroquery.gaia import Gaia
from astropy.time import Time

from astropy.io.votable.exceptions import VOTableSpecWarning
# Silence those pesky warnings from astropy VOTable
warnings.filterwarnings("ignore", category=VOTableSpecWarning)

# Query some area
coord = SkyCoord(ra=280, dec=-60, unit=(u.degree, u.degree), frame='icrs')
radius = 30*u.arcsec
r = Gaia.query_object(coordinate=coord, radius=radius)

# Assemble a SkyCoord entity with all the entries
stars = SkyCoord(ra = list(r['ra']), 
                 dec = list(r['dec']), 
                 obstime= Time(list(r['ref_epoch']), format='decimalyear'),
                 frame = 'icrs', 
                 unit=(u.deg, u.deg), 
                 pm_ra_cosdec = list(r['pmra'].filled(fill_value=0)) * u.mas/u.yr,
                 pm_dec = list(r['pmdec'].filled(fill_value=0)) * u.mas/u.yr,
                 # I must specify a generic distance to the target,
                 # if I want to later on propagate the proper motions
                 distance = 1*u.kpc, 
                 )
# propagate the proper motions to 2019-04-17 00:00:00.0
stars_now = stars.apply_space_motion(new_obstime = Time('2019-04-17 00:00:00.0'))

# Look at star number 1, to see how we did ...
print(stars[0].to_string('hmsdms'))
print(stars_now[0].to_string('hmsdms'))

