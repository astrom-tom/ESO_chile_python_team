# A Python script to query the GAIA catalogue and test WCSAxes() plots
#
# Written April 2019, F.P.A. Vogt; fvogt@eso.org
# ----------------------------------------------------------------------------------------


# A Python script to query the GAIA catalogue and test WCSAxes() plots
#
# Written April 2019, F.P.A. Vogt; fvogt@eso.org
# ----------------------------------------------------------------------------------------

# Import the packages
import os

from astropy.wcs import WCS
from astropy.io import fits
from astropy.coordinates import SkyCoord
import astropy.units as u
from astropy.time import Time

from astroquery.gaia import Gaia

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec # GRIDSPEC !
gs = gridspec.GridSpec(1, 1, height_ratios=[1], width_ratios=[1], 
                       left=0.15, right=0.95, bottom=0.08, top=0.9, wspace=0.02, hspace=0.03)

# A simple DSS2-R band image, obtained from http://archive.eso.org/dss/dss
fits_fn = os.path.join('.','random_DSS2-Red.fits') 

# Get the WCS info
hdu = fits.open(fits_fn)[0]
wcs = WCS(hdu.header)

# Create the figure
plt.close(1)
fig = plt.figure(1, figsize=(6.94,7))
ax = fig.add_subplot(gs[0,0], projection=wcs)

# Show the data
ax.imshow(hdu.data, cmap='Greys', origin='lower', vmin=4e3, vmax = 1e4)

# Reset to see all the pixels, including the ones at the edges!
ax.set_xlim(-0.5, hdu.data.shape[1] - 0.5)
ax.set_ylim(-0.5, hdu.data.shape[0] - 0.5)

# Query Gaia for the area
coord = SkyCoord(ra='03h16m22.4s', dec='+31d32m49s', frame='icrs')
radius = 80*u.arcsec
r = Gaia.query_object(coordinate=coord, radius=radius)

# Extract the stars as a SkyCoord entity
stars = # FILL ME

# Propagate the proper motion backwards
stars_then = # FILL ME

# Show the stars then
ax.scatter() # FILL ME

# Show the stars now
ax.scatter() #FILL ME

# Add some quick labels
ax.set_xlabel('R.A. [J2000]')
ax.set_ylabel('Dec. [J2000]')

plt.show()