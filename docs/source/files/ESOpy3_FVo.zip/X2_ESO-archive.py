# A Python script to query the ESO archive
#
# Written April 2019, F.P.A. Vogt; fvogt@eso.org
# ----------------------------------------------------------------------------------------


# Import the packages
import numpy as np
from astroquery.eso import Eso

# Connect to the archive
eso = Eso()
eso.ROW_LIMIT=-1 
eso.login("FILL-ME") 

# eso.query_instrument('muse', help=True)

# How much time was spent on MUSE "SKY" field since the start of operations?
table_muse = eso.query_instrument('muse', column_filters={'dp_cat':'SCIENCE',
                                                          'dp_type':'FILL-ME',
                                                          'stime':'FILL_ME', 
                                                          'etime':'2019-04-17',
                                                          #'prog_type':'1',
                                                          #'pi_coi':'JDOE',
                                                          },
                                                          #columns={},
                                                          )
time_on_actual_sky = np.sum(table_muse['EXPTIME [s]']) # Total time spent in that spot
print('Total time on MUSE SKY: %.1f hours' % (time_on_actual_sky/3600))


# How much Science time spent on HAWKI since P104 ?
table_hawki = # FILL-ME


time_on_sky = np.sum(table_hawki['EXPTIME']) # Total time spent in that spot
print('HAWKI time on source in P104: %.1f hours' % (time_on_sky/3600))