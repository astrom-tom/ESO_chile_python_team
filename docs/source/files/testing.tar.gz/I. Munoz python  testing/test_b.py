# test_b.py
# Test parametrization
import pytest
from mylib import *


@pytest.mark.parametrize("value, sqv",
	[(2,4), (4,16), (0,0)])				
def test_sq(value, sqv):
	assert(square(value) == sqv)


@pytest.mark.parametrize("value, sqv", [(i, i**2) for i in range(10)])				
def test_sq1(value, sqv):
	assert(square(value) == sqv)

@pytest.mark.parametrize("value, sqv", [(-i, (-i)**2) for i in range(10)])				
def test_sq2(value, sqv):
	assert(square(value) == sqv)

@pytest.mark.parametrize("a,b,expected",
	[ (0,1,0), (2,2,2*2), (3,1,3), 
		(-3,1,-3),
		pytest.mark.xfail((3,-1,3))
		 ])
def test_mul(a,b, expected):
	assert(mul(a,b) == expected)
				
@pytest.mark.parametrize("a", range(4))
@pytest.mark.parametrize("b", range(4))
def  test_all(a,b):
	assert(mul(a,b) == a*b)

