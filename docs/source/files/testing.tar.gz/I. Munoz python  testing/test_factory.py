# test_factory.py
import pytest
from mylib import makepow

@pytest.mark.parametrize("exp", range(10))
def test_makepow(exp):
	f = makepow(exp)
	for x in range(10):
		assert( f(x) == x**exp)
	