# conftest.py
# content of conftest.py
import pytest
import smtplib

@pytest.fixture(scope="module",
                params=["smtp.gmail.com", "mail.python.org"])
def xsmtp(request):
    smtp = smtplib.SMTP(request.param, 587, timeout=5)
    yield smtp
    print ("finalizing %s" % smtp)
    smtp.close()


@pytest.fixture
def smtp(request):
	smtp = smtplib.SMTP("smtp.gmail.com", 587, timeout=5)
	yield smtp
	smtp.close()
	