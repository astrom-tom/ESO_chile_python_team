# mylib.py
import operator
from functools import reduce

def mul(a,b):
	return sum([a for x in range(b)])

def square(x):
	return mul(x,x)


def makepow(n):
	"""
	A factory function.
	Creates pow_n(x) function which returns the value of x**n
	 """
	def _pow(x):
		#print(x,n)
		if n==0:
			return 1
		return reduce(operator.mul, [x]*n)
	return _pow


