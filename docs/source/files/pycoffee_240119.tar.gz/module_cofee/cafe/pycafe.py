####a proper header is welcome!
#### This file is part of the cafe package
#### and this source code do whatever...

#licence:
#author:
#place:
#date:
#last version:
#log change...

###imports
import numpy


###the code
def blabla(N):
    '''
    this function takes a number N and return the sqrt

    Parameters
    ----------
    N
        float, efowihewf

    Return
    ------
    s 
        float, sqrt of N
    '''
    s = numpy.sqrt(N)
    return s
