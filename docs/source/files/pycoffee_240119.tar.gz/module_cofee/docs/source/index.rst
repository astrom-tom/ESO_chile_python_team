.. cafe documentation master file, created by
   sphinx-quickstart on Thu Jan 24 11:13:48 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cafe's documentation!
================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

this is thre pycafe code

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
