from setuptools import setup

setup(
    name = 'PyCofee',
    version = 0.1,
    author = 'RThomas',
    packages = ['cafe'],
    #entry_points = {'gui_scripts': ['dfitspy = dfitspy.__main__:main',],},
    description = 'examplepycoffee',
    license = 'GPLv3',
    python_requires = '>=3.5',
    install_requires = ["numpy >= 1.16"])

