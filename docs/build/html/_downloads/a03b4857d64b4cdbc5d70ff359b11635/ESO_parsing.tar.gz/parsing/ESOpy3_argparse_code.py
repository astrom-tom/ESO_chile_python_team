##########################
### R. THOMAS - ESOpy3 ###
###         2019       ###
##########################



####paramters
A = 5
B = 10
C = 15
P = True
#############


##make the code:

AB = A*B
Final = AB/C

if P is True:
	print(Final)
