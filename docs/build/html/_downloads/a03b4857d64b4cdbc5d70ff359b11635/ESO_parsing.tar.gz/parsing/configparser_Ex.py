import configparser

###again, create a configparser object
config = configparser.ConfigParser()

##and read the configuration file
config.read('ex.conf')

##get input section:
inputfile = config.get('Input', 'filename_input')
input_dir = config.get('Input', 'directory_input')


###get Parameters
A = config.getfloat('Parameters', 'A')
B = config.getfloat('Parameters', 'B')
C = config.getfloat('Parameters', 'C')
D = config.getfloat('Parameters', 'D')
alpha1 = config.getfloat('Parameters', 'alpha1')
alpha2 = config.getfloat('Parameters', 'alpha2')


##get Ouput section:
final_file = config.get('Output', 'filename_final')
directory_output = config.get('Output', 'directory_output')

print('\nInputfile:', inputfile)
print('outputfile:', final_file)


