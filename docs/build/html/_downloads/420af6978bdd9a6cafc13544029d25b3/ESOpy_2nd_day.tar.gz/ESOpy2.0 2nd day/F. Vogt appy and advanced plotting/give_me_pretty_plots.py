# This file contains basic rcparams to make plots look good. 
# Place it in your Python path, and have it accesible inside any of your scripts !
#
# Created Jan. 2018 for the ESOpy 2.0; F.P.A. Vogt; fvogt@eso.org

import matplotlib as mpl

# ----------------------------------------------------------------------------------------
# Make the plots look good
# ----------------------------------------------------------------------------------------

mpl.rc('MacOSX')
mpl.rc('font',**{'family':'sans-serif', 'serif':['Computer Modern Serif'], 
             'sans-serif':['Helvetica'], 'size':16, 
             'weight':500, 'variant':'normal'})
mpl.rc('axes',**{'labelweight':'normal', 'linewidth':1})
mpl.rc('ytick',**{'major.pad':8, 'color':'k', 'direction':'in'})
mpl.rc('xtick',**{'major.pad':8, 'color':'k', 'direction':'in'})
mpl.rc('mathtext',**{'default':'regular','fontset':'cm', 
                 'bf':'monospace:bold'})
mpl.rc('text', **{'usetex':True})
mpl.rc('text.latex',
       preamble=r'\usepackage{cmbright},\usepackage{relsize},\usepackage{upgreek},\usepackage{amsmath}')
mpl.rc('contour', **{'negative_linestyle':'solid'}) # dashed | solid

# ----------------------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------------------

aa_1c = 6.92 # width of a single column plot, in inches (x2)
aa_2c = 14.16 # width of a 2-column plot, in inches (x2)