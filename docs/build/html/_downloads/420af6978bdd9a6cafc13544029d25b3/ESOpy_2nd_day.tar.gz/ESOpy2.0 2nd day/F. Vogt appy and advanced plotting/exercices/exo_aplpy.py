
import os
import numpy as np

import matplotlib.pyplot as plt # Gives access to basic plotting functions

import matplotlib.gridspec as gridspec # GRIDSPEC !
import aplpy

# A simple DSS2-R band image, obtained from http://archive.eso.org/dss/dss
fits_fn = os.path.join('.','NGC6121-off2-N-astrom_DSS2-Red.fits') 

# First, create the figure
plt.close(2)
fig = plt.figure(2, figsize=(6.92,7))

# Let's keep things simple here ... only one plot
ax1 = aplpy.FITSFigure(fits_fn, figure=fig, north=False, subplot=[0.12,0.08,0.85,0.85])

# Show the image in a grayscale arcsinh stretch
ax1.show_grayscale(invert = True, stretch='arcsinh') 

# Some coordinates of interest
target = np.array([245.95570, -26.48259])
vlt_gs = np.array([246.03592, -26.41527])

# The field-of-view of your instrument, in degrees (center is at [0,0])
# (Bonus points to the first one to shout which instrument this is ...)
inst_fov= np.array([[0.0086683878,   0.0084439565],[359.99128-360., 0.008499508],
                    [359.99172-360.,-0.0082782215],[0.0080579666,  -0.008389310]])

# ----------------------- Now it's your turn ! ----------------------------

# Step 1 (1 line): show the target location with a cross

# Step 2 (1 line): show the VLT guide star location

# Step 3 (1 line): recenter on the area of interest

# Step 4 (1 line): add a scalebar of 2 arcmin to the top right corner

# Step 5 (0 line): fix the plot so all the labels are visible

# Step 6 (5 lines): show the instrument field-of-view [ax.show_polygons() may help ...]

                   
# -------------------------------------------------------------------------

plt.show()
plt.savefig('exo_aplpy.png')