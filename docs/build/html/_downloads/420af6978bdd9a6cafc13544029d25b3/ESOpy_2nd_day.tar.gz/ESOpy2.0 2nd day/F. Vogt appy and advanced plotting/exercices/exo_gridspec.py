import numpy as np # For creating some fake data

import matplotlib.pyplot as plt # Gives access to basic plotting functions
import matplotlib.gridspec as gridspec # GRIDSPEC !

# Ok, let us start by creating some fake data
x = np.random.randn(1000)
y = np.random.randn(1000)
z = np.sqrt(x**2+y**2)

# `randn` generates an array of shape ``(d0, d1, ..., dn)``, filled
# with random floats sampled from a univariate "normal" (Gaussian)
# distribution of mean 0 and variance 1.

plt.close(2)
fig = plt.figure(2, figsize=(14.17,7))

# Now, create the gridspec structure, as required

### Bonus points if you turn the colorbar from horizontal to vertical ! ###

# ----------------------- Now it's your turn ! -------------------------------------------
gs = gridspec.GridSpec(3,4, height_ratios=[1,1,1], width_ratios=[1,1,1,1],
                       left=0.0, right=1, bottom=0.0, top=1, wspace=0.0, hspace=0.0)

# First, the scatter plot
ax1 = plt.subplot(gs[0,0])

# and let us not forget the colorbar !
cbax = plt.subplot(gs[0:2,1:3])

# And now the (vertical) histogram
ax1v = plt.subplot(gs[0:3,3])

# And now another (horizontal) histogram
ax1h = plt.subplot(gs[1:3,0])

# Finally, show some 'spectra' in the right panel
ax2 = plt.subplot(gs[2,1:3])

# ----------------------------------------------------------------------------------------
# ------ Then the plots themselves ... no need to modify anything below ... or do you ?


plt1 = ax1.scatter(x, y, c = z, 
                   marker = 's', s=20, edgecolor = 'none',alpha =1,
                   cmap = 'viridis_r', vmin =0 , vmax = 4)

# Define the limits, labels, ticks as required
ax1.grid(True)
ax1.set_xlim([-4,4])
ax1.set_ylim([-4,4])
ax1.set_xlabel(r' ') # Force this empty !
ax1.set_xticks(np.linspace(-4,4,9)) # Force this to what I want - for consistency with histogram below !
ax1.set_xticklabels([]) # Force this empty !
ax1.set_ylabel(r'My y label')

cb = plt.colorbar(cax = cbax, mappable = plt1, orientation = 'horizontal', ticklocation = 'top')
cb.set_label(r'Colorbar !', labelpad=10)

# Plot the data
bins = np.arange(-4,4,0.1)
ax1v.hist(y,bins=bins, orientation='horizontal', color='k', edgecolor='w')

# Define the limits, labels, ticks as required
ax1v.set_yticks(np.linspace(-4,4,9)) # Ensures we have the same ticks as the scatter plot !
ax1v.set_xticklabels([])
ax1v.set_yticklabels([])
ax1v.set_ylim([-4,4])
ax1v.grid(True)

# Plot the data
bins = np.arange(-4,4,0.1)
ax1h.hist(x, bins=bins, orientation='vertical', color='k', edgecolor='w')

# Define the limits, labels, ticks as required
ax1h.set_xticks(np.linspace(-4,4,9)) # Ensures we have the same ticks as the scatter plot !
ax1h.set_yticklabels([])
ax1h.set_xlim([-4,4])
ax1h.set_xlabel(r'My x label')
ax1h.grid(True)

# Plot the data
plt.plot(x[::20], ls = '-', color='darkviolet', lw=2)
plt.plot(y[::20], ls = '-', color ='tomato', lw=2)

# Define the limits, labels, ticks as required
ax2.set_xlabel('My other x label')
ax2.set_ylabel('My other y label')
ax2.set_ylim([-4,4])
ax2.grid(True)

plt.savefig('exo_gridspec.png')