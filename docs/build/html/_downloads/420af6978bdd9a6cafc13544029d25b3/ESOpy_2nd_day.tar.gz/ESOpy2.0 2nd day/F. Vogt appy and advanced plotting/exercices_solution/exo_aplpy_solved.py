
import os
import numpy as np

import matplotlib.pyplot as plt # Gives access to basic plotting functions

import matplotlib.gridspec as gridspec # GRIDSPEC !
import aplpy


# A simple DSS2-R band image, obtained from http://archive.eso.org/dss/dss
fits_fn = os.path.join('.','NGC6121-off2-N-astrom_DSS2-Red.fits') 

# First, create the figure
plt.close(2)
fig = plt.figure(2, figsize=(6.92,7))

# Let's keep things simple here ... only one plot
ax1 = aplpy.FITSFigure(fits_fn, figure=fig, north=False, subplot=[0.2,0.08,0.75,0.85])

# Show the image in a grayscale arcsinh stretch
ax1.show_grayscale(invert = True, stretch='arcsinh') 

# Some coordinates of interest
target = np.array([245.95570, -26.48259])
vlt_gs = np.array([246.03592, -26.41527])

# The field-of-view of your instrument, in degrees (center is at [0,0])
# (Bonus points to the first one to shout which instrument this is ...)
inst_fov= np.array([[0.0086683878,   0.0084439565],[359.99128-360., 0.008499508],
                    [359.99172-360.,-0.0082782215],[0.0080579666,  -0.008389310]])

# ----------------------- Now it's your turn ! ----------------------------

# Step 1 (1 line): show the target location with a cross
ax1.show_markers(target[0],target[1], marker='x', facecolor='darkorange', s=1e2,lw=2)

# Step 2 (1 line): show the VLT guide star location
ax1.show_markers(vlt_gs[0],vlt_gs[1], marker='o', facecolor='None', edgecolor='crimson', s=1e2,lw=2)

# Step 3 (1 line): recenter on the area of interest
ax1.recenter(0.5*(target[0]+vlt_gs[0]),0.5*(target[1]+vlt_gs[1]), radius=3.5/60)

# Step 4 (1 line): add a scalebar of 2 arcmin to the top right corner
ax1.add_scalebar(120./3600,label="2'", corner = 'top right', color = 'k', frame=1, linewidth=2)

# Step 5 (0 line): fix the plot so all the labels are visible
# [fix at the top]

# Step 6 (5 lines): show the instrument field-of-view [ax.show_polygons() may help ...]

polygon = [] # it's a list

# Accounts for the declination in the RA size of the field
inst_fov[:,0] = inst_fov[:,0]/np.cos(np.radians(target[1]))

# Store the actual field corners inside the polygon
for (j,corner) in enumerate(inst_fov):
      polygon.append(inst_fov[j]+ [target[0],target[1]])
           
ax1.show_polygons([np.array(polygon)], edgecolor = 'darkorange', linewidth = 2, zorder = 10)  
           
# -------------------------------------------------------------------------

plt.show()
plt.savefig('exo_aplpy_solved.png')