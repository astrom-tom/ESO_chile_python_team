import configparser
import sys

###create a configparser object
config = configparser.ConfigParser() 

##retrieve the config file
config_file = sys.argv[1] 

##and read it
config.read(config_file)

###retrieve the parameters
A = config.get('Values', 'A')
B = config.get('Values', 'B')
A2 = config.get('Parameters', 'A')
C = config.get('Parameters', 'C')


###let's rewrite in the config file
###wanna add a section?
section_names  = list(config)  ##<<<--- thie retrieve the section names
if 'Section1' not in section_names:
    config.add_section('Section1')  ###<---this add a new section

config.set('Section1', 'an_int', '20') ##<---and in this section we write a new parameter

##and let's write it in the disk
with open(config_file, 'w') as configfile:
    config.write(configfile)

