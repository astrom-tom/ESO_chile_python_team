import argparse #<--- it is in the python standard library

parser = argparse.ArgumentParser(description='your description')

####positional argument
parser.add_argument("age", help='your age')

###optional argument
parser.add_argument("-p","--place", help='birthplace')

###store true
parser.add_argument("-k", action = 'store_true', help = 'test store_true')

###retrieve the arguments
args = parser.parse_args()

print(args.k)
print(args.age)
print(args.place)


