# test_a.py
from mylib import *

def test_something():
	assert(0==0)

def test_mul():
	assert(mul(2,2) == 4)
	assert(mul(-2,2) == -4)
	#assert(mul(2, -2) == -4)

def test_sq(x,y,z):
	assert(square(2) == 4)
	assert(square(4) == 16)

